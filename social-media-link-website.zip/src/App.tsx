import AnimatedBackground from "./components/AnimatedBackground";
import Profile from "./components/Profile";
import SocialLinkCard from "./components/SocialLinkCard";
import Footer from "./components/Footer";
import { socialLinks } from "./data/links";

export default function App() {
  return (
    <div className="relative min-h-screen flex items-center justify-center px-4 py-12">
      <AnimatedBackground />

      <div className="relative z-10 w-full max-w-md mx-auto">
        <div className="bg-gray-900/40 backdrop-blur-xl border border-white/5 rounded-3xl p-6 sm:p-8 shadow-2xl">
          {/* Profile Section */}
          <Profile />

          {/* Social Links */}
          <div className="flex flex-col gap-3">
            {socialLinks.map((link, index) => (
              <SocialLinkCard key={link.name} link={link} index={index} />
            ))}
          </div>

          {/* Footer */}
          <Footer />
        </div>
      </div>
    </div>
  );
}
