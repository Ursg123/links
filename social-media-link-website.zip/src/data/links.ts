export interface SocialLink {
  name: string;
  url: string;
  icon: string;
  color: string;
  hoverColor: string;
  description?: string;
}

export const profile = {
  name: "ItsSRGProductions",
  handle: "@itsSRGProductions",
  bio: "✨ Creator | Dreamer ✨",
  avatar: "", // You can add your avatar URL here
};

export const socialLinks: SocialLink[] = [
  {
    name: "Instagram",
    url: "https://www.instagram.com/itssrgproductions/?hl=en",
    icon: "instagram",
    color: "from-purple-500 to-pink-500",
    hoverColor: "hover:shadow-pink-500/30",
    description: "Check out my photos",
  },
  {
    name: "YouTube",
    url: "https://www.youtube.com/@ItsSRGProductions/videos",
    icon: "youtube",
    color: "from-red-500 to-red-700",
    hoverColor: "hover:shadow-red-500/30",
    description: "Watch my videos",
  },
  {
    name: "TikTok",
    url: "https://www.tiktok.com/@itssrgproductions",
    icon: "tiktok",
    color: "from-gray-700 to-gray-900",
    hoverColor: "hover:shadow-gray-500/30",
    description: "Check out my shorts",
  },
  {
    name: "Discord",
    url: "https://discord.gg/kqXhNWVzrf",
    icon: "discord",
    color: "from-indigo-400 to-violet-600",
    hoverColor: "hover:shadow-violet-500/30",
    description: "Join my community",
  },
  {
    name: "Website",
    url: "https://yourwebsite.com",
    icon: "globe",
    color: "from-teal-400 to-cyan-600",
    hoverColor: "hover:shadow-cyan-500/30",
    description: "Visit my portfolio",
  },
];
