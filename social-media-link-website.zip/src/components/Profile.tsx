import { motion } from "framer-motion";
import { Sparkles } from "lucide-react";
import { profile } from "../data/links";

export default function Profile() {
  const initials = profile.name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);

  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      className="flex flex-col items-center gap-4 mb-8"
    >
      {/* Avatar */}
      <div className="relative group">
        {/* Animated ring */}
        <div className="absolute -inset-1 bg-gradient-to-r from-violet-500 via-pink-500 to-cyan-500 rounded-full opacity-75 blur group-hover:opacity-100 transition-opacity duration-500 animate-spin-slow" />
        <div className="relative">
          {profile.avatar ? (
            <img
              src={profile.avatar}
              alt={profile.name}
              className="w-28 h-28 rounded-full object-cover border-2 border-gray-900"
            />
          ) : (
            <div className="w-28 h-28 rounded-full bg-gradient-to-br from-violet-500 via-purple-500 to-pink-500 flex items-center justify-center border-2 border-gray-900 shadow-2xl">
              <span className="text-white text-3xl font-bold tracking-wide">
                {initials}
              </span>
            </div>
          )}
        </div>
        {/* Sparkle indicator */}
        <div className="absolute -top-1 -right-1">
          <Sparkles className="w-5 h-5 text-yellow-400" style={{
            animation: "sparkle-pulse 2s ease-in-out infinite"
          }} />
        </div>
      </div>

      {/* Name and handle */}
      <div className="text-center space-y-1">
        <motion.h1
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="text-2xl sm:text-3xl font-bold text-white tracking-tight"
        >
          {profile.name}
        </motion.h1>
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="text-gray-400 text-sm font-medium"
        >
          {profile.handle}
        </motion.p>
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="text-gray-300 text-sm mt-2"
        >
          {profile.bio}
        </motion.p>
      </div>

      {/* Divider */}
      <motion.div
        initial={{ opacity: 0, scaleX: 0 }}
        animate={{ opacity: 1, scaleX: 1 }}
        transition={{ delay: 0.6, duration: 0.5 }}
        className="w-16 h-px bg-gradient-to-r from-transparent via-violet-500 to-transparent mt-2"
      />

      <style>{`
        @keyframes sparkle-pulse {
          0%, 100% { opacity: 1; transform: scale(1) rotate(0deg); }
          50% { opacity: 0.5; transform: scale(1.2) rotate(15deg); }
        }
        @keyframes spin-slow {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        .animate-spin-slow {
          animation: spin-slow 8s linear infinite;
        }
      `}</style>
    </motion.div>
  );
}
