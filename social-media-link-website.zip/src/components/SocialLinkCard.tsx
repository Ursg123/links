import { motion } from "framer-motion";
import { ExternalLink, Mail, Globe } from "lucide-react";
import {
  Instagram,
  Twitter,
  Youtube,
  Github,
  Linkedin,
  TikTok,
  Spotify,
  Discord,
} from "./CustomIcons";
import { SocialLink } from "../data/links";

const iconMap: Record<string, React.ElementType> = {
  instagram: Instagram,
  twitter: Twitter,
  youtube: Youtube,
  github: Github,
  linkedin: Linkedin,
  spotify: Spotify,
  tiktok: TikTok,
  discord: Discord,
  mail: Mail,
  globe: Globe,
};

export default function SocialLinkCard({
  link,
  index,
}: {
  link: SocialLink;
  index: number;
}) {
  const Icon = iconMap[link.icon] || Globe;

  return (
    <motion.a
      href={link.url}
      target="_blank"
      rel="noopener noreferrer"
      initial={{ opacity: 0, y: 30, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{
        delay: index * 0.08 + 0.3,
        duration: 0.5,
        ease: [0.25, 0.46, 0.45, 0.94],
      }}
      whileHover={{ scale: 1.03, y: -3 }}
      whileTap={{ scale: 0.98 }}
      className={`group relative w-full flex items-center gap-4 p-4 rounded-2xl bg-white/5 backdrop-blur-md border border-white/10 hover:border-white/20 shadow-lg ${link.hoverColor} transition-all duration-300 cursor-pointer`}
    >
      {/* Gradient background on hover */}
      <div
        className={`absolute inset-0 rounded-2xl bg-gradient-to-r ${link.color} opacity-0 group-hover:opacity-10 transition-opacity duration-300`}
      />

      {/* Icon */}
      <div className="relative flex-shrink-0">
        <div
          className={`w-12 h-12 rounded-xl bg-gradient-to-br ${link.color} flex items-center justify-center shadow-lg group-hover:shadow-xl transition-all duration-300`}
        >
          <Icon className="w-5 h-5 text-white" />
        </div>
      </div>

      {/* Text */}
      <div className="flex-1 min-w-0">
        <h3 className="text-white font-semibold text-sm sm:text-base group-hover:text-white transition-colors">
          {link.name}
        </h3>
        {link.description && (
          <p className="text-gray-400 text-xs sm:text-sm truncate">
            {link.description}
          </p>
        )}
      </div>

      {/* Arrow */}
      <div className="flex-shrink-0 opacity-0 group-hover:opacity-100 transition-all duration-300 translate-x-[-8px] group-hover:translate-x-0">
        <ExternalLink className="w-4 h-4 text-gray-400 group-hover:text-white" />
      </div>
    </motion.a>
  );
}
