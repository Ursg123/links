import { useState } from "react";
import { motion } from "framer-motion";
import { Heart, Share2, Check } from "lucide-react";

export default function Footer() {
  const [copied, setCopied] = useState(false);

  const handleShare = async () => {
    try {
      if (navigator.share) {
        await navigator.share({
          title: "My Social Links",
          text: "Check out my social media links!",
          url: window.location.href,
        });
      } else {
        await navigator.clipboard.writeText(window.location.href);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      }
    } catch {
      await navigator.clipboard.writeText(window.location.href);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 1.5 }}
      className="mt-10 pb-4 text-center"
    >
      {/* Share button */}
      <motion.button
        onClick={handleShare}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 hover:border-white/20 transition-all duration-300 text-sm text-gray-400 hover:text-gray-300"
      >
        {copied ? (
          <>
            <Check className="w-4 h-4 text-green-400" />
            <span className="text-green-400">Copied!</span>
          </>
        ) : (
          <>
            <Share2 className="w-4 h-4" />
            <span>Share my links</span>
          </>
        )}
      </motion.button>

      {/* Copyright */}
      <p className="mt-6 text-gray-500 text-xs flex items-center justify-center gap-1.5">
        Made with <Heart className="w-3 h-3 text-pink-500 fill-pink-500" /> by{" "}
        <span className="text-gray-400">ItsSRGProductions</span>
      </p>
    </motion.div>
  );
}
